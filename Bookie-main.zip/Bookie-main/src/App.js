import logo from './logo.svg';
import './App.css';
import Landing from './component/landingPage/Landing';
import Collection from './component/collection/Collection';
import Navigation from './component/Navigation/Navigation';


function App() {
  return (
    <div className="App">
    
    <Navigation/>
    </div>
  );
}

export default App;
