import React from 'react';
import { useState } from 'react';
import Navbar from './landingPage/Navbar';
import { useDispatch, useSelector } from 'react-redux';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

export default function AddBook() {
  const books = useSelector((state) => state.books);
  const dispatch = useDispatch();

  const [title, setTitle] = useState('');
  const [desc, setDesc] = useState('');
  const [source, setSource] = useState('');
  const [price, setPrice] = useState('');

  function handleAdd(e) {
    e.preventDefault();
    dispatch({
      type: 'ADD_BOOK',
      payload: { id: books.reverse()[0].id + 1, title, price, desc, img: source }
    });

    toast.success(`${title} added successfully`, {
      position: 'top-center',
      autoClose: 2000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
      theme: 'light',
    });
  }

  return (
    <div>
      <Navbar />
      <ToastContainer />

      <div className="" id="loginModal1" tabIndex="-1" aria-labelledby="exampleModalLabel">
        <div className="modal-dialog" style={{ width: '40%', marginTop: '40px' }}>
          <div className="modal-content">
            <div className="modal-body">
              <form>
                <div className="mb-3">
                  <label htmlFor="exampleInputEmail1" className="form-label">
                    Title
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="exampleInputEmail1"
                    aria-describedby="emailHelp"
                    onChange={(e) => setTitle(e.target.value)}
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="exampleInputEmail1" className="form-label">
                    Price
                  </label>
                  <input
                    type="number"
                    className="form-control"
                    id="exampleInputEmail1"
                    aria-describedby="emailHelp"
                    onChange={(e) => setPrice(e.target.value)}
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="exampleInputPassword1" className="form-label">
                    Description
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="exampleInputPassword1"
                    onChange={(e) => setDesc(e.target.value)}
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="exampleInputPassword1" className="form-label">
                    Source of Image book
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="exampleInputPassword1"
                    onChange={(e) => setSource(e.target.value)}
                  />
                </div>
                <div className="mb-3 form-check"></div>
                <button
                  type="button"
                  className="btn btn-outline-primary w-100 mt-5"
                  onClick={(e) => handleAdd(e)}
                >
                  Add Book
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
