import React from 'react'

export default function FirstSec() {
  return (
    <div style={{width:'100%', height:'90vh', padding:"100px 0",marginBottom:'200px',marginTop:'0px'}}>
      <div className='container' style={{padding:'30px 0'}}>
        <div className='row'>


          <div className='col-4' style={{display:'flex', flexDirection:'column', gap:'15px', justifyContent:'center'}}>
            <h5 style={{color:'#a7a7a7', fontSize:'18px', fontFamily:'Montserrat, sans-serif', fontWeight:400, lineHeight:'1.35em'}}>Featured Book</h5>
            <h2 style={{color:'#000009', fontSize:'24px', lineHeight:'1.35em', fontWeight:300}}>The Complete Idiots Guide to Graphic Design</h2>
            <p style={{color:'#757575', fontFamily:'"PT Serif", serif', fontSize:'17px',lineHeight:'30px'}}>From advanced selectors to generated content to web f
            onts, and from gradients, shadows, and rounded corners to elegant animations, CSS3
             hold a universe of creative possibilities. No one can better guide you through thes
             e galaxies than Dan Cederholm.</p>
             <button type="" style={{background:'#2f2b35', color:'white', fontSize:'14px', fontFamily:'Montserrat, sans-serif', padding:'8px 10px', border:'none', letterSpacing:'1px',display:'inline-block', borderRadius:'50px', marginTop:'40px', width:'170px'}}>Get this book</button>
          </div>


          <div className='col-8'>
            <div className='row'>
              
            <div className='col-6'>
              <img src='https://demo.tokopress.com/bookie/wp-content/uploads/sites/7/2016/06/home1-featured-01.jpg' style={{width:'100%', height:'100%'}}/>
          </div>

          <div className='col-6'>
          <img src='https://demo.tokopress.com/bookie/wp-content/uploads/sites/7/2016/06/home1-featured-02.jpg' style={{width:'100%', height:'100%', borderRadius:'5px'}}/>
          </div>
            </div>
          </div>
          

        </div>
      </div>
    </div>
  )
}
