import React from 'react'
import 'bootstrap/dist/css/bootstrap.min.css'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'
export default function Navbar(props) {
  const cartLength = useSelector((state) => state.cart)
  return (
    <div className={props.dark === false ? 'menu container' : 'menuDark container-fluid'}>
     <h1 className='logo'>Bookie</h1>
     <div className='navbart'>
        <ul className='navul'>
<li><a href='/'>Home</a></li>

<li><Link to="/products">bookstore</Link></li>

<li><Link to="/contact">Contact</Link></li>

<li><Link to="/signup">Register</Link></li>
<li><Link to="/login">Login</Link></li>

<li><Link to="/about">About</Link></li>

<li><Link to='/cart'>Cart ({cartLength.length})</Link></li>


        </ul>
     </div>



     
    </div>
  )
}
