import React from 'react'
import Navbar from './Navbar'
import "bootstrap/dist/css/bootstrap.min.css"
import "./Landing.css"
import { Link as ScrollLink } from 'react-scroll';
export default function Landing() {
  return (
<div className='landingPage-section' id='top'>
    <div className='container'>
<Navbar dark={false}/>
    <div className='row'>
        <div className='col-7' style={{position:'relative'}}>
          <h5 className='myh5'>Reading is the best for get idea</h5>
          <h1 className='myh1'>Start Reading</h1>
          <button className='mybtn'>See More</button>
        </div>
        <div className='col-5'></div>
    </div>
</div>


<ScrollLink className='span' to="top" smooth={true} duration={500}>
<span style={{position:"fixed", bottom:"20px", right:"20px", fontSize:"25px", background:"#000009", width:"40px", height:"40px", display:"flex", alignItems:"center", justifyContent:"center", color:"white", cursor:"pointer", zIndex:3000}}>↑</span>
        </ScrollLink>
</div>
  )
}
