import React from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Landing from '../landingPage/Landing';
import Collection from '../collection/Collection';
import Shop from '../Shop/Shop';
import Cart from '../Cart/Cart';
import FirstSec from '../FirstSec/FirstSec';
import SecondSec from '../SecondSec/SecondSec';
import Signup from '../../data/Singup';
import Login from '../../data/Login';
import Beforfooter from '../Beforefooter';
import Search from '../Search';
import AddBook from '../AddBook';
import ProductSlider from '../ProductSlider';
import Checkout from '../Checkout';
import Footer from '../Footer';
import Contact from '../Contact';
import About from '../About';

export default function Navigation() {
  return (
    <BrowserRouter>
    <Routes>
    
    <Route path='/' element={<div>
        <Landing/>
        <Search/>
        <Collection/>
        <FirstSec/>   
    <SecondSec/>
    <Beforfooter/>
    <Footer/>
    </div>}/>
        <Route path='books/:name' element={<Shop/>}/>
        <Route path='/cart' element={<Cart/>}/>
        <Route path='/signup' element={<Signup/>}/>
        <Route path='/login' element={<Login/>}/>
        <Route path='/addbook' element={<AddBook/>}/>
        <Route path='/products' element={<ProductSlider/>}/>
        <Route path='/about' element={<About/>}/>
        <Route path='/checkout' element={<Checkout/>}/>
        <Route path='/contact' element={<Contact/>}/>





    </Routes>
    </BrowserRouter>
  )
}
