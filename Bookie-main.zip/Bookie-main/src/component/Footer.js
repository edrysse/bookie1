import React from 'react'
import { Link } from 'react-router-dom'

export default function Footer() {
  return (
    <div>
        <div className='footer' style={{background:'#2f2b35', width:'100%', padding:'150px 0', textAlign:'center'}}>
      <ul style={{display:'flex', listStyleType:'none', gap:'50px', justifyContent:'center'}}>
        <li><Link to="/" style={{textDecoration:'none', color:'white'}}>Home</Link></li>
        <li><Link to="/" style={{textDecoration:'none', color:'white'}}>My Account</Link></li>
        <li><Link to="/products" style={{textDecoration:'none', color:'white'}}>Book Store</Link></li>
        <li><Link to="/contact" style={{textDecoration:'none', color:'white'}}>Contact</Link></li>
      </ul>
      <span style={{color:'white'}}>Copyright © Bookie</span>
    </div>
    </div>
  )
}
