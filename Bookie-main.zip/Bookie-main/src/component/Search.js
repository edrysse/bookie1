import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';
import "bootstrap/dist/css/bootstrap.min.css"
export default function Search() {
  const navigate = useNavigate()
const [searchValue, setSearchValue] = useState()
  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && searchValue !== "") {
      navigate(`/books/${searchValue}`)
    }
  };


  const handleFind = () => {
      navigate(`/books/${searchValue}`)
  };


  return (
    <div className='container' style={{padding:"30px 0"}}>
          <div className='row'>
            
            <div className='col-8'>
            <input placeholder='search' type="text" className='' onChange={(e) => setSearchValue(e.target.value)} onKeyDown={handleKeyDown} style={{width:"100%", outline:"none", border:"none", borderBottom:"1px solid #757575", padding:"7px 7px"}}/>
            </div>


            <div className='col-4'>
          <button className="" style={{background:'#2f2b35', color:'white', fontSize:'14px', fontFamily:'Montserrat, sans-serif', padding:'8px 10px', border:'none', letterSpacing:'1px',display:'inline-block', borderRadius:'50px', width:'100%', fontWeight:600}} onClick={() => handleFind()}>Find Book</button>
            </div>
          </div>
          

          

    </div>
  )
}
