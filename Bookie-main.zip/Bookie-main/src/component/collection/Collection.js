import React, { useEffect } from 'react';
import { BrowserRouter as Router, Link } from 'react-router-dom';
import './Collection.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useDispatch, useSelector } from 'react-redux';

import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

export default function Collection() {
  const books = useSelector((state) => state.books)
  const booksc = useSelector((state) => state.cart)

  useEffect(() => {
    console.log(booksc)
  }, [booksc])
  const dispatch = useDispatch()

  function addTo(id, title, price, desc, img){
    dispatch({type:"ADD_BOOK_CART", payload:{id: id,title: title,price: price,desc: desc, img: img}})
    toast.success(`${title} added successfully`, {
      position: "top-center",
      autoClose: 2000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
      theme: "light",
      });
  }

  return (
      <div className='' style={{ width: '100%', background: 'whiteSmoke', padding:"100px 0 0 50px" }} id='collection'>

        <h3 className='products'>Popular Books</h3>

        <ToastContainer />
        <div className='container'>
          <div className='row'>
            {books.slice(0, 4).map(function (book, i) {
              return (
                <div className='col-3' key={i}>
                  <div
                    style={{
                      width: '100%',
                      height:"100%",
                      padding: '5px 10px 30px 10px',
                      borderRadius: '5px',
                      background: 'white',
                      border: '1px solid #727260',
                    }}
                  >
                    <img src={book.img} style={{ width: '100%', height: '80%' }} />
                    <div
                      style={{
                        display: 'flex',
                        gap: '10px',
                        flexDirection: 'column',
                        justifyContent: 'center',
                        width: '100%',
                        textAlign: 'right',
                      }}
                    >
                      <span className='titlecss'>{book.title}</span>
                      <span className='pricecss'>{book.price}$</span>
                    </div>
                    <div
                      style={{
                        display: 'flex',
                        justifyContent: 'center',
                        width: '100%',
                        textAlign: 'right',
                      }}
                    >
                      <Link to={`books/${book.title}`}
                          style={{
                            background: 'transparent',
                            border: '1px solid #727272',
                            borderTopLeftRadius: '16px',
                            borderBottomLeftRadius: '16px',
                            padding: '4px 20px',
                            borderRight: 'none',
                            width: '50%',
                            outline: 'none',
                            textDecoration:"none"
                          }}>
                        <button
                        style={{
                          background: 'transparent',
                          border: 'none',
                          outline: 'none',
                          display:"flex",
                          gap:"7px",
                        }}
                        ><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAAWVJREFUSEvVVdtxgzAQlAYKSSqJXYnjHjgPfzF/DEcPIZWETkIjzMXr6DRC5mE75sP6ATTS7Wp3T1iz8rAr1zfPB5Dn+QtUKcuyw/NhJyCid2PMhzEGAC0zb/8N4Iq+GWNQPBwdM7/eDUBEnyeWG8dWC0OSszynZ8PM+5sAHNudKxyybUTky1r7rZPW2qKqquMiQJZlG2stisYSYG8nIn8sg+L4FpFtXdftJEBk2EWrKEO3DnINBjP78PgXxKvve6RgjK0WaEWkALvD4XAUEayPhzd4cAIi+olMizfumbnBJBFBb5g8eTrvR7gi0DxMSJMkSaGNM1fc+eENnjUZYFigZi0xV6KhwYsp0k3OH83+mDI6N9D/agAnnc/5DMK6AGGDjZo8xSzI+5mhiygaUK8G3eqTdg/ATm9IbHaywRcPEjbYTQAwWWMan9JdfGjOC/2vNnkuNnqaNE27MRIP++FMkXh+gF+GvZ4ZB46ohQAAAABJRU5ErkJggg=="/>
                          DETAIL
                        </button>
                      </Link>
                      <Link onClick={() => addTo(book.id, book.title, book.price, book.desc, book.img)}
                        style={{
                          background: 'transparent',
                          border: '1px solid #727272',
                          borderTopRightRadius: '16px',
                          borderBottomRightRadius: '16px',
                          padding: '4px 30px',
                          width: '50%',
                          outline: 'none',
                          textDecoration:"none"
                        }}>
                      <button
                        style={{
                          background: 'transparent',
                          border: 'none',
                          outline: 'none',
                          display:"flex", gap:"7px"
                        }}
                       ><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAAPhJREFUSEvdlTEOgzAMAGPxkfIT+Ams7RojttIN4aztWn5SftJ+BLmK1KBQERQCDG3GyPjscxJA7Lxg5/zijwCIyBvqehFRrPMNinYHmOqLoqiY+byym5yI2lEHJmFZloe+759rAEQ0mJk8RYj4EEIkgZCWiHLzrQuQCSHuIYAoiuK6rl+zgBWaRtVPzsCQQzQxc6qU6uzOnTdZSpkAgJ6F7+qIKP0OdgJsTVOV+VJn3yJE1IPOAODSNE3lm9RLkQ5aosk++94AHeh7s4MBIVoWdfBRdQWAIzPflFInk0BKObm/GGC/tLYK1/5igKvSzTpYM4ff/ye/Aa9cexndMrzaAAAAAElFTkSuQmCC"/>
                        BUY
                      </button></Link>
                      </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
  );
}
