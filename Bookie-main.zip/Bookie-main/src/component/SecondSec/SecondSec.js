import React from 'react'
import "./SecondSec.css"
import { Link as ScrollLink } from 'react-scroll';

export default function SecondSec() {
  return (
    <div className='hahaOne' style={{width:'100%', height:'50vh'}}>
      <h2 style={{color:'white', fontWeight:300, position:'absolute', top:'50%', left:'50%', transform:'translate(-50%, -50%)', fontSize:'40px'}}>Browse Through Our Complete Library</h2>



      <ScrollLink className='span' to="collection" smooth={true} duration={1000}>
      <span style={{color:'white', fontWeight:300, position:'absolute', bottom:'25%', left:'50%', transform:'translateX(-50%)', fontSize:'15px', letterSpacing:'1px', cursor:'pointer'}}>BROWSE COLLECTION →</span>

        </ScrollLink>

    </div>
  )
}
