import "./Shop.css"
import { useParams } from 'react-router-dom'
import React, { useEffect } from 'react'
import Navbar from "../landingPage/Navbar"
import { useSelector } from "react-redux"
export default function Shop() {
    const books = useSelector((state) => state.books)
  const {name} = useParams()
  const book = books.find((book) => book.title == name)
const s=0


 useEffect(() =>{
    console.log(book)
 }, [])
  return (
    <div style={{width:"100%"}}>
    <Navbar dark={true}/>
    {book? 
    <div className="container my-5 py-3">
    <div className="row">
        <div className="col-md-6 d-flex justify-content-center mx-auto product">
            <img src={book.img} alt={book.title}height="400px" />
        </div>
        <div className="col-md-6 d-flex flex-column justify-content-center">
            <h1 className="display-5 fw-bold">{book.title}</h1>
            <hr />
            <h2 className="my-4">${book.price}</h2>
            <p className="lead">{book.desc}</p>
            <button className="btn btn-outline-primary my-5">hh</button>
        </div>
    </div>
</div> : 'Loading...'}
    </div>
)
}






