import React from 'react'
import Navbar from '../landingPage/Navbar'
import { useSelector } from 'react-redux'
import { useDispatch } from 'react-redux'
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { Link } from 'react-router-dom';
export default function Cart() {
    const books = useSelector((state) => state.cart)
    const dispatch = useDispatch();

    function removeTo(id, title){
        dispatch({type:"REMOVE_FROM_CART", payload: id})
        toast.error(`${title} deleted successfully`, {
            position: "top-center",
            autoClose: 2000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            theme: "light",
            });
      }

  return (
    <div style={{width:"100%", height:"100vh", position:"relative"}}>
        <Navbar/>
        <ToastContainer />
        <div>
        {books.length > 0? books.map(function(book, i){
            return(
                <div className="container py-4" key={i}>
                <button onClick={() => removeTo(book.id, book.title)} className="btn-close float-end" aria-label="Close"></button>
                <div className="row justify-content-center">
                    <div className="col-md-4">
                        <img src={book.img} alt={book.title} height="200px" width="180px" />
                    </div>
                    <div className="col-md-4">
                        <h3>{book.title}</h3>
                        <p className="lead fw-bold">${book.price}</p>
                    </div>
                </div>
                
            </div>
                
            )
        })
         : <h1 style={{position:"absolute", left:"50%"}}>Your Cart is Empty</h1>}


{books.length > 0 ?         <Link to="/checkout"><button className="btn btn-outline-primary mb-5 w-25 mx-auto" style={{position:"absolute", left:"40%"}}>Proceed To checkout</button></Link>
 : null}        </div>
        
    </div>
  )
}
