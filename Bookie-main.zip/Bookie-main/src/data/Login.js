import React, { useEffect } from 'react';
import { useState } from 'react';
import Navbar from '../component/landingPage/Navbar';
import axios from "axios"
import {useNavigate} from 'react-router-dom'

const Login= () => {
    
    const navigate=useNavigate()
  const [email, setemail] = useState('');
  const [password, setpassword] = useState('');


  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!email.trim() || !password.trim()) {
        return;
      }
    
  
    try {
        const response = await axios.get(`http://localhost:5000/admins?email=${email}&password=${password}`);
        
        if (response.data.length > 0) {
          
          alert('Your login has been made successfully')
          navigate('/addbook');
        } else {
            alert('Invalid email or password');
        }
    } catch (error) {
        console.error('Error logging in:', error);
    }
  };

  return (
    <>
    <Navbar/>
      <div className="" id="loginModal1" tabIndex="-1" aria-labelledby="exampleModalLabel">
        <div className="modal-dialog" style={{width:'40%',marginTop:'40px'}}>
          <div className="modal-content">
           
            <div className="modal-body">
              
              <form onSubmit={handleSubmit}>
            
                <div className="mb-3">
                  <label htmlFor="exampleInputEmail1" className="form-label">
                    Email address
                  </label>
                  <input type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" onChange={(e) => setemail(e.target.value)} />
                  <div id="emailHelp" className="form-text">
                    We'll never share your email with anyone else.
                  </div>
                </div>
                
                <div className="mb-3">
                  <label htmlFor="exampleInputPassword1" className="form-label">
                    Password
                  </label>
                  <input type="password" className="form-control" id="exampleInputPassword1" onChange={(e) => setpassword(e.target.value)} />
                </div>
               
                <div className="mb-3 form-check">
                  <input type="checkbox" className="form-check-input" id="exampleCheck1" />
                  <label className="form-check-label" htmlFor="exampleCheck1">
                    Check me out
                  </label>
                </div>
                <button type="submit" className="btn btn-outline-primary w-100 mt-5">
                  Log In
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>

     
    </>
  );
};

export default Login;
